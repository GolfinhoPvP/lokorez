<?php
//no direct accees
defined ('_JEXEC') or die ('resticted aceess');

include_once(JPATH_ROOT . "/templates/" . $this->template . '/lib/php/tmptools.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
<?php JHTML::_('behavior.mootools'); ?>
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/system/css/general.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/css/template.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/css/typography.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/css/joomla.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/css/navigation.css" type="text/css" />
<link rel="stylesheet" href="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/css/modules.css" type="text/css" />
<script src="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/js/moomenu.js" type="text/javascript"></script>
<script src="<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/js/pqutlz.js" type="text/javascript"></script>
<?php if($font_resizer=="true") { ?>
<script language="javascript" type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/fontresizer.js"></script>
<?php } ?>
<?php include_once(JPATH_ROOT . "/templates/" . $this->template . '/js/logreg.php'); ?>
</head>
<body>
<div id="wrap">
<!--[if lt IE 7]>
  <div style='border: 1px solid #F7941D; background: #FEEFDA; text-align: center; clear: both; height: 75px; position: relative;'>
    <div style='position: absolute; right: 3px; top: 3px; font-family: courier new; font-weight: bold;'><a href='#' onclick='javascript:this.parentNode.parentNode.style.display="none"; return false;'><img src='<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/images/nomoreie6/ie6nomore-cornerx.jpg' style='border: none;' alt='Close this notice'/></a></div>
    <div style='width: 640px; margin: 0 auto; text-align: left; padding: 0; overflow: hidden; color: black;'>
      <div style='width: 75px; float: left;'><img src='<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/images/nomoreie6/ie6nomore-warning.jpg' alt='Warning!'/></div>
      <div style='width: 275px; float: left; font-family: Arial, sans-serif;'>
        <div style='font-size: 14px; font-weight: bold; margin-top: 12px;'>You are using an outdated browser</div>
        <div style='font-size: 12px; margin-top: 6px; line-height: 12px;'>For a better experience using this site, please upgrade to a modern web browser.</div>
      </div>
      <div style='width: 75px; float: left;'><a href='http://www.firefox.com' target='_blank'><img src='<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/images/nomoreie6/ie6nomore-firefox.jpg' style='border: none;' alt='Get Firefox 3.5'/></a></div>
      <div style='width: 75px; float: left;'><a href='http://www.microsoft.com/windows/internet-explorer/default.aspx' target='_blank'><img src='<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/images/nomoreie6/ie6nomore-ie8.jpg' style='border: none;' alt='Get Internet Explorer 8'/></a></div>
      <div style='width: 73px; float: left;'><a href='http://www.apple.com/safari/download/' target='_blank'><img src='<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/images/nomoreie6/ie6nomore-safari.jpg' style='border: none;' alt='Get Safari 4'/></a></div>
      <div style='float: left;'><a href='http://www.google.com/chrome' target='_blank'><img src='<?php echo $this->baseurl?>/templates/<?php echo $this->template?>/images/nomoreie6/ie6nomore-chrome.jpg' style='border: none;' alt='Get Google Chrome'/></a></div>
    </div>
  </div>
<![endif]-->	
<?php if ($this->countModules( 'reg' )) : ?>
		<div id="reg" style="visibility:hidden;">
		<a id="closeReg" href="#"><img style="float:right;" class="nostyle" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/close.png" alt="Close" title="Close" /></a>
			<div class="clr"></div>
			<div class="inside">
				<jdoc:include type="modules" name="reg" style="none" />
			</div>	
		</div>
	<?php endif; ?>
	<?php if ($this->countModules( 'login' )) : ?>
		<div id="login" style="visibility:hidden;">
		<a id="closeLogin" href="#"><img style="float:right;" class="nostyle" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/close.png" alt="Close" title="Close" /></a>
			<div class="clr"></div>		
			<div class="inside">
				<jdoc:include type="modules" name="login" style="none" />
			</div>	
		</div>
	<?php endif; ?>
<!--End of Login and Reg module-->
	
	<div id="header">
	<a id="logo" href="<?php echo $this->baseurl?>"></a>
	<?php if ($this->countModules('login or reg')) { ?>
		<div id="logreg">
		<?php if ($this->countModules('login')) { ?>
			<a class="toolTips" id="toggleLogin" href="#" title="Login :: Click the link to Login">Login</a>
		<?php } ?>	
		<?php if ($this->countModules('reg')) { ?>
			<a class="toolTips" id="toggleReg" href="#" title="Register :: Click the link to Register">Register</a>
		<?php } ?>	
		</div>
	<?php } ?>
	<?php if ($this->countModules('top-menu')) { ?>
		<div id="top-menu">
			<jdoc:include type="modules" name="top-menu" style="none" />
		</div>
	<?php } ?>
	
	<?php if($font_resizer=="true") { ?>
		<div id="fontsizer">
			<a href="javascript:changeFontSize(-2);"><img class="nostyle toolTips" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/small-size.png" alt="Decrease font size" title="Decrease font size" /></a>
			<a href="javascript:revertStyles();"><img class="nostyle toolTips" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/reset-size.png" alt="Reset font size" title="Reset font size" /></a>
			<a href="javascript:changeFontSize(2);"><img class="nostyle toolTips" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/images/big-size.png" alt="Increase font size" title="Increase font size" /></a>
		</div>
	<?php } ?>	
	<?php if ($this->countModules('search')) { ?>	
	<div id="search">
		<jdoc:include type="modules" name="search" style="none" />
	</div>
	<?php } ?>
	</div>
	
	<?php if ($this->countModules('hornav')) { ?>
	<div id="hornav">
		<div class="inside">
			<jdoc:include type="modules" name="hornav" />
		</div>	
	</div>	
	<?php } ?>
	
	<?php if($this->countModules('slides')) { ?>
		<div class="clr"></div>
		<div id="slides">
			<jdoc:include type="modules" name="slides" style="none" />
		</div>
	<?php } ?>

	<div class="clr"></div>	
	<div class="container <?php echo $class ; ?>">
	<div id="content<?php echo $contentwidth; ?>">
		<div class="inside">
			<jdoc:include type="message" />
			<jdoc:include type="component" />
		</div>
	</div>
	<?php if ($this->countModules ( 'right' )) : ?>
	<div id="right">
		<jdoc:include type="modules" name="right" style="pq_xhtml" />
	</div>	
	<?php endif; ?>
	<div class="clr"></div>
	</div>
	
<div style="margin-left: -4000px;">
<a href="http://www.sitegratisgratis.com.br">criar site</a>
<a href="http://www.elevadoresmais.com.br">elevadores</a>
<a href="http://www.templatejoomla.com.br">joomla</a>
<a href="http://www.barrafunda.org">barra funda</a>
<a href="http://www.negociosemitaquera.com.br">itaquera</a>
<a href="http://www.templatejoomla.com.br/hospedagem-joomla.html">hospedagem joomla</a>
<a href="http://hospedagemsites10.com.br/">hospedagem</a>
</div>
	<?php if($this->countModules( 'breadcrumb' )) { ?>
		<!-- PATHWAY -->
		<div class="clr"></div>	
		<div id="breadcrumb">
			<div class="inner">
				<strong>You are here : </strong><jdoc:include type="module" name="breadcrumbs" />
			</div>
		</div>
		<!-- //PATHWAY -->
	<?php } ?>
	<div class="clr"></div>
	
	<?php if ($this->countModules ( 'user1 or user2 or user3' )) : ?>
		<div id="bottom">
		<?php if ($this->countModules ( 'user1' )) : ?>
		<div id="user1" style="width:<?php echo $bottomwidth ?>;">
			<div class="bottom-padding">
				<jdoc:include type="modules" name="user1" style="pq_raw" />
			</div>	
		</div>
		<?php endif; ?>
		<?php if ($this->countModules ( 'user2' )) : ?>
		<div id="user2" style="width:<?php echo $bottomwidth ?>;">
			<div class="bottom-padding">
				<jdoc:include type="modules" name="user2" style="pq_raw" />
			</div>	
		</div>
		<?php endif; ?>
		<?php if ($this->countModules ( 'user3' )) : ?>
		<div id="user3" style="width:<?php echo $bottomwidth ?>;">
			<div class="bottom-padding">
				<jdoc:include type="modules" name="user3" style="pq_raw" />
			</div>	
		</div>
		<?php endif; ?>
		<div class="clr"></div>
	</div>
	<?php endif; ?>
	<div id="footer">
		<div class="padding">
		<div id="footer-nav">
			<jdoc:include type="modules" name="footer-nav" style="none" />
		</div>
		<?php
			# You are not allowed to remove copyright information
			# To remove copyright information please contact with us using pqsofts@gmail.com email address
		?>
		<div class="cp">Copyright &copy; Todos os direitos reservados.</div>
		<div class="clr"></div>
		<div id="validation">
		<a href="http://jigsaw.w3.org/css-validator/validator?uri=<?php echo JURI::base(); ?>&amp;warning=1&amp;profile=css3&amp;usermedium=all" target="_blank" title="CSS Validity" style="text-decoration: none;">CSS Valid | </a>
		<a href="http://validator.w3.org/check/referer" target="_blank" title="XHTML Validity" style="text-decoration: none;">XHTML Valid | </a>
		<a href="#header">Top</a><br  />
		</div>
	</div>
	<div class="clr"></div>
	</div>
</div>
</body>
</html>

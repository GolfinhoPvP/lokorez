<?php
//Modules handling
if ($this->countModules( 'right' )) {
$contentwidth="80";
$class="rightimg";
}else{
$contentwidth="100";
$class="";
}
$font_resizer = ($this->params->get("font_resizer", 0)  == 1) ? "false" : "true";
$bottom = 0;
if ($this->countModules('user1')) $bottom++;
if ($this->countModules('user2')) $bottom++;
if ($this->countModules('user3')) $bottom++;
if ( $bottom == 3 ) {
	$bottomwidth = '33.3%';}
elseif ( $bottom == 2 ) {
	$bottomwidth = '50%';
} else if ($bottom == 1) {
	$bottomwidth = '100%';
}   
?>
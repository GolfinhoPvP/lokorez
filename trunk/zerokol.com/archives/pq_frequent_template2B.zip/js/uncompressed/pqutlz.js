window.addEvent("domready",function(){
	var list = $$('.moduletable_menu li a');
	new SmoothScroll({ duration: 500, transition: Fx.Transitions.linear}, window);
	list.each(function(element) {
	var fx = new Fx.Styles(element, {duration:200, wait:false});
	element.addEvent('mouseenter', function(){
		fx.start({
			'padding-left': 22
		});
	});
 
	element.addEvent('mouseleave', function(){
		fx.start({
			'padding-left': 16
		});
	});
	
	});

	var list2 = $$('.moduletable_menu li li a');
	list2.each(function(element) {
	var fx = new Fx.Styles(element, {duration:200, wait:false});
	
	element.addEvent('mouseenter', function(){
		fx.start({
			'padding-left': 42
		});
	});
 
	element.addEvent('mouseleave', function(){
		fx.start({
			'padding-left': 32
		});
	});
	});
	
//Tool tips	

	var toolTips = new Tips($$('.toolTips'), {
	initialize:function(){
		this.fx = new Fx.Style(this.toolTip, 'opacity', {duration: 500, wait: false}).set(0);
	},
	onShow: function(toolTip) {
		this.fx.start(1);
	},
	onHide: function(toolTip) {
		this.fx.start(0);
	}
});
	
});
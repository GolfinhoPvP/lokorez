<script type="text/javascript">
window.addEvent("domready",function(){
//Login form
<?php if ($this->countModules('login')) { ?>
	$('login').setStyle('height','auto');
<?php }	?> 
<?php if ($this->countModules('reg')) { ?>
	$('reg').setStyle('height','auto');
	var myReg = new Fx.Slide('reg').hide(); 
<?php } ?>	
<?php if ($this->countModules('login')) { ?>
	var myLogin = new Fx.Slide('login').hide(); 
    $('toggleLogin').addEvent('click', function(e){
		e = new Event(e);
		$('login').setStyle('visibility','visible');
		myLogin.toggle();
		<?php if ($this->countModules('reg')) { ?>
		myReg.slideOut();
		<?php } ?>
		e.stop();
	});

    $('closeLogin').addEvent('click', function(e){
		e = new Event(e);
		myLogin.slideOut();
		e.stop();
	});
<?php } ?>
//Reg form
<?php if ($this->countModules('reg')) { ?>
    $('toggleReg').addEvent('click', function(e){
		e = new Event(e);
		$('reg').setStyle('visibility','visible');
		<?php if ($this->countModules('login')) { ?>
		myLogin.slideOut();
		<?php } ?>
		myReg.toggle();
		e.stop();
	});

    $('closeReg').addEvent('click', function(e){
		e = new Event(e);
		myReg.slideOut();
		e.stop();
	});
<?php } ?>	
});	
</script>	
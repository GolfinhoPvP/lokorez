<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

function modChrome_slider($module, &$params, &$attribs)
{
	jimport('joomla.html.pane');
	// Initialize variables
	$sliders = & JPane::getInstance('sliders');
	$sliders->startPanel( JText::_( $module->title ), 'module' . $module->id );
	echo $module->content;
	$sliders->endPanel();
}

function modChrome_pq_xhtml($module, &$params, &$attribs)
{ ?>
	<div class="moduletable<?php echo $params->get('moduleclass_sfx'); ?>">
		<?php if ($module->showtitle != 0) { ?>
			<h3>
				<?php
					$title = $module->title;
					$title = split(' ', $title);
					$title[0] = '<span>'.$title[0].'</span>';
					$title= join(' ', $title);
					echo $title; 
				?>
			</h3>
		<?php } ?>
		<div class="padding">	
			<?php echo $module->content; ?>
		</div>	
	</div>
	<div class="gap"></div>
	<?php
}

function modChrome_pq_raw($module, &$params, &$attribs)
{ ?>
	<div class="module<?php echo $params->get('moduleclass_sfx'); ?>">
		<?php if ($module->showtitle != 0) { ?>
		<h3><?php echo $module->title; ?></h3>
		<?php } ?>
		<div class="padding">	
			<?php echo $module->content; ?>
		</div>	
	</div>
	<div class="gap"></div>
	<?php
}
?>
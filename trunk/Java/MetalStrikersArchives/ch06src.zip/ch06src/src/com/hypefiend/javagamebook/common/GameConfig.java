package com.hypefiend.javagamebook.common;

import org.apache.log4j.*;

/**
 * GameConfig.java
 *
 * todo: gameconfig
 *
 * @author <a href="mailto:bret@hypefiend.com">bret barker</a>
 * @version 1.0
 */

public class GameConfig {
    public int getInt(String key, int defaultValue) {
	return 0;
    }

    public String getString(String key, int defaultValue) {
	return null;
    }
}
